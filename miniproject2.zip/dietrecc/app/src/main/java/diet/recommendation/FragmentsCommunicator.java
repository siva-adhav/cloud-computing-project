package diet.recommendation;

public interface FragmentsCommunicator {

    void respond(String data1, int data2);

}
